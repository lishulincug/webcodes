# webcodec-h264-bench
Benchmark your webcodecs here!

## Useful stuff
- Use mp4info (Bento4) to get the codec strings